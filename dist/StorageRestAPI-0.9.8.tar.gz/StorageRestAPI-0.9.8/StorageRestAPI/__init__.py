from .Hitachi import RestAPI
