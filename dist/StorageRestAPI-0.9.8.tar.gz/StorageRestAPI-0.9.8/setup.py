from distutils.core import setup

setup(
    name='StorageRestAPI',
    packages=['StorageRestAPI'],
    version='0.9.8',
    description='Hitachi Storage REST API Project',
    url='https://github.com/pascalhubacher/HitachiStorageRestAPI'
)